package com.day9;
import com.day8.*;//public access modifier
class B {

	public static void main(String[] args) {
	A obj=new A();
	obj.display();

	}

}
