package com.day4;

public class B {
public static void main(String[] args) {
	A obj=new A();
	//trying to access private method of anothar class
	obj.display();
}
}
