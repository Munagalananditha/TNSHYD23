package com.day4;
//private access modifier
public class A {
	private void display() {
		System.out.println("TNS Session");
	}

}
