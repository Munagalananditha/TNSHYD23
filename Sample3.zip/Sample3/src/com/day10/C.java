package com.day10;
//user defined package//
public class C {

	public static void main(String[] args) {
		System.out.println("sri indu college");

	}

}
