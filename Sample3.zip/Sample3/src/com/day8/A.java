package com.day8;
//public access modifier
public class A {
public void display() {
	System.out.println("TNS Sessions");
}
}
