package com.day;

public class A {
int a=5;
static int b=15;
int display() {
	return 10;
}
static void display1() {
	System.out.println(10);
}
public static void main(String[] args) {
	A a1=new A();
	System.out.println(a1.a);
	a1.display();

System.out.println(A.b);
A.display1();


}
}