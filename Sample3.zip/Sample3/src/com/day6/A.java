package com.day6;
//protected access modifier
public class A {
public void display() {
	System.out.println("TNS Session");
}
}
