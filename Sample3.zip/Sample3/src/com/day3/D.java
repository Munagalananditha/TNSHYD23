package com.day3;

public class D {

	public static void main(String[] args) {
		C c1=new C();
		System.out.println(c1.c);
		c1.display();
		System.out.println(C.d);
C.display1();
	}

}
