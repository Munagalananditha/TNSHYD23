package com.day3;

public class C {
int c=20;
static int d=30;
int display() {
	return 10;
}
static void display1() {
	System.out.println(10);
}
}
