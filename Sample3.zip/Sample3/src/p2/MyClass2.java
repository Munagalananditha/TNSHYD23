package p2;
import com.day5.*;
public class MyClass2 {

	public static void main(String[] args) {
		MyClass1 obj=new MyClass1();
		obj.display();

	}

}
